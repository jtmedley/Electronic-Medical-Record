package com.example.medley.medicalrecord;

import org.junit.Test;

import static org.junit.Assert.*;

public class ClassSocketHandlerTest {

    @Test
    public void startThread() {
    }

    @Test
    public void getPortNumber() {
    }

    @Test
    public void socketOperation() {
    }
}