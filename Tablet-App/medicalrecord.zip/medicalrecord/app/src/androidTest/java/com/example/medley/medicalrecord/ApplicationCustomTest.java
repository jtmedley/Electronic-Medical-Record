package com.example.medley.medicalrecord;

import android.support.test.runner.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class ApplicationCustomTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void onCreate() {
    }

    @Test
    public void setLocationSettings() {
    }

    @Test
    public void getLocale() {
    }

    @Test
    public void setLocale() {
    }

    @Test
    public void getAppContext() {
    }

    @Test
    public void onConfigurationChanged() {
    }

    @Test
    public void attachBaseContext() {
    }
}