package com.example.medley.medicalrecord;

import android.support.test.runner.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class BaseActivityClassTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void onCreate() {
    }

    @Test
    public void setActionBar() {
    }

    @Test
    public void dispatchTouchEvent() {
    }

    @Test
    public void onOptionsItemSelected() {
    }

    @Test
    public void onCreateOptionsMenu() {
    }

    @Test
    public void toastUiThread() {
    }

    @Test
    public void classDialogHelper() {
    }

    @Test
    public void getActivityContext() {
    }

    @Test
    public void attachBaseContext() {
    }

    @Test
    public void onRestart() {
    }

    @Test
    public void startNew() {
    }

    @Test
    public void startUpdate() {
    }

    @Test
    public void startView() {
    }

    @Test
    public void onBackPressed() {
    }
}