package com.example.medley.medicalrecord;

import org.junit.Test;

import static org.junit.Assert.*;

public class PageSearchRecordsTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void makeQuery() {
    }

    @Test
    public void checkResults() {
    }

    @Test
    public void putPatient() {
    }

    @Test
    public void getRowDisplay() {
    }

    @Test
    public void makeCreateButtonListener() {
    }

    @Test
    public void onCreate1() {
    }

    @Test
    public void handleResults() {
    }

    @Test
    public void displayResults() {
    }

    @Test
    public void setImage() {
    }

    @Test
    public void setRowText() {
    }
}