package com.example.medley.medicalrecord;

import org.junit.Test;

import static org.junit.Assert.*;

public class PageTranslateTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onRestart() {
    }
}