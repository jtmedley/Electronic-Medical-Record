package com.example.medley.medicalrecord;

import org.junit.Test;

import static org.junit.Assert.*;

public class PageHelpTest {

    @Test
    public void onCreate() {
    }
}