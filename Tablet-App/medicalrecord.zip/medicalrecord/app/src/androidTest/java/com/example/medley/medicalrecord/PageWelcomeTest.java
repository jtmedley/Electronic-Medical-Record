package com.example.medley.medicalrecord;

import org.junit.Test;

import static org.junit.Assert.*;

public class PageWelcomeTest {

    @Test
    public void onBackPressed() {
    }

    @Test
    public void onCreate() {
    }
}