package com.example.medley.medicalrecord;

import org.junit.Test;

import static org.junit.Assert.*;

public class ClassImageHandlerTest {

    @Test
    public void socketOperation() {
    }

    @Test
    public void getPortNumber() {
    }
}